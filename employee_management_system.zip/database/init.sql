-- database/init.sql
CREATE DATABASE employees_db;
\connect employees_db;
CREATE TABLE IF NOT EXISTS employees (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  position VARCHAR(150) NOT NULL,
  department VARCHAR(150) NOT NULL,
  salary INTEGER NOT NULL CHECK (salary >= 0),
  hire_date DATE NOT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive'))
);

INSERT INTO employees (name, email, position, department, salary, hire_date, status) VALUES
('Ayu Santoso','ayu.santoso@example.com','Software Engineer','IT',8000000,'2023-02-15','active'),
('Budi Wijaya','budi.wijaya@example.com','HR Specialist','HR',6000000,'2022-06-01','active'),
('Citra Dewi','citra.dewi@example.com','Data Analyst','Analytics',7500000,'2024-01-10','active'),
('Dedi Prasetyo','dedi.prasetyo@example.com','DevOps Engineer','IT',9000000,'2021-11-20','inactive'),
('Eka Putri','eka.putri@example.com','Product Manager','Product',12000000,'2020-08-05','active');
