const API_BASE = (window._API_BASE_ || 'http://localhost:8000') + '/api';

async function api(path, opts={}){
  const res = await fetch(API_BASE + path, {...opts});
  if(!res.ok){
    const err = await res.json().catch(()=>({detail:res.statusText}));
    throw new Error(err.detail || res.statusText);
  }
  return res.json().catch(()=>null);
}

async function fetchList(){
  const q = document.getElementById('search').value;
  const status = document.getElementById('status').value;
  const params = new URLSearchParams();
  if(q) params.append('search', q);
  if(status) params.append('status', status);
  const data = await api('/employees?' + params.toString());
  renderList(data);
}

function renderList(items){
  const div = document.getElementById('list');
  if(!items || items.length===0){ div.innerHTML = '<p>No employees</p>'; return; }
  let html = '<table><thead><tr><th>Name</th><th>Email</th><th>Position</th><th>Department</th><th>Salary</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
  for(const e of items){
    html += `<tr><td>${e.name}</td><td>${e.email}</td><td>${e.position}</td><td>${e.department}</td><td>${e.salary}</td><td>${e.status}</td><td><button data-id="${e.id}" class="btnEdit">Edit</button><button data-id="${e.id}" class="btnDel">Delete</button></td></tr>`
  }
  html += '</tbody></table>';
  div.innerHTML = html;
  document.querySelectorAll('.btnEdit').forEach(b=>b.addEventListener('click', onEdit));
  document.querySelectorAll('.btnDel').forEach(b=>b.addEventListener('click', onDelete));
}

async function onDelete(e){
  const id = e.target.dataset.id;
  if(!confirm('Delete (soft)?')) return;
  await api('/employees/' + id, { method: 'DELETE' });
  fetchList();
}

async function onEdit(e){
  const id = e.target.dataset.id;
  const data = await api('/employees/' + id);
  openForm(data);
}

function openForm(data=null){
  const modal = document.getElementById('formModal');
  const form = document.getElementById('employeeForm');
  document.getElementById('formTitle').textContent = data ? 'Edit Employee' : 'Add Employee';
  form.dataset.id = data?.id || '';
  form.name.value = data?.name || '';
  form.email.value = data?.email || '';
  form.position.value = data?.position || '';
  form.department.value = data?.department || '';
  form.salary.value = data?.salary || 0;
  form.hire_date.value = data?.hire_date || '';
  form.status.value = data?.status || 'active';
  modal.classList.remove('hidden');
}

function closeForm(){
  document.getElementById('formModal').classList.add('hidden');
}

document.getElementById('btnSearch').addEventListener('click', fetchList);
document.getElementById('btnAdd').addEventListener('click', ()=>openForm());
document.getElementById('btnCancel').addEventListener('click', closeForm);

document.getElementById('employeeForm').addEventListener('submit', async function(ev){
  ev.preventDefault();
  const id = ev.target.dataset.id;
  const payload = {
    name: ev.target.name.value,
    email: ev.target.email.value,
    position: ev.target.position.value,
    department: ev.target.department.value,
    salary: parseInt(ev.target.salary.value,10),
    hire_date: ev.target.hire_date.value,
    status: ev.target.status.value
  };
  try{
    if(id){
      await api('/employees/' + id, { method: 'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
      alert('Updated');
    } else {
      await api('/employees', { method: 'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
      alert('Created');
    }
    closeForm();
    fetchList();
  }catch(err){ alert(err.message) }
});

// init
fetchList();
