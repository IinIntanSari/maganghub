import os
from fastapi import FastAPI, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from fastapi.middleware.cors import CORSMiddleware
from . import models, schemas, crud
from .database import engine, Base, get_db
from dotenv import load_dotenv

load_dotenv()

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Employee Management API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/employees", response_model=list[schemas.EmployeeOut])
def read_employees(
    department: str | None = Query(None),
    status: str | None = Query(None),
    search: str | None = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    db: Session = Depends(get_db),
):
    skip = (page - 1) * page_size
    total, items = crud.get_employees(db, skip=skip, limit=page_size, department=department, status=status, search=search)
    return items

@app.get("/api/employees/{employee_id}", response_model=schemas.EmployeeOut)
def read_employee(employee_id: int, db: Session = Depends(get_db)):
    db_employee = crud.get_employee(db, employee_id)
    if not db_employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    return db_employee

@app.post("/api/employees", response_model=schemas.EmployeeOut, status_code=status.HTTP_201_CREATED)
def create_employee(employee: schemas.EmployeeCreate, db: Session = Depends(get_db)):
    exists = db.query(models.Employee).filter(models.Employee.email == employee.email).first()
    if exists:
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_employee(db, employee)

@app.put("/api/employees/{employee_id}", response_model=schemas.EmployeeOut)
def update_employee(employee_id: int, updates: schemas.EmployeeUpdate, db: Session = Depends(get_db)):
    db_employee = crud.get_employee(db, employee_id)
    if not db_employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    if updates.email:
        other = db.query(models.Employee).filter(models.Employee.email == updates.email, models.Employee.id != employee_id).first()
        if other:
            raise HTTPException(status_code=400, detail="Email already in use")
    return crud.update_employee(db, db_employee, updates)

@app.delete("/api/employees/{employee_id}")
def delete_employee(employee_id: int, soft: bool = True, db: Session = Depends(get_db)):
    db_employee = crud.get_employee(db, employee_id)
    if not db_employee:
        raise HTTPException(status_code=404, detail="Employee not found")
    crud.delete_employee(db, db_employee, soft=soft)
    return {"detail": "deleted" if not soft else "soft-deleted (status updated to inactive)"}

@app.get("/api/stats")
def stats(db: Session = Depends(get_db)):
    return crud.get_stats(db)
