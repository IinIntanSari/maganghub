from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional
from datetime import date

class EmployeeBase(BaseModel):
    name: str = Field(..., min_length=1)
    email: EmailStr
    position: str = Field(..., min_length=1)
    department: str = Field(..., min_length=1)
    salary: int = Field(..., ge=0)
    hire_date: date
    status: Optional[str] = 'active'

    @validator("status")
    def status_must_be_valid(cls, v):
        if v not in ("active", "inactive"):
            raise ValueError("status must be 'active' or 'inactive'")
        return v

class EmployeeCreate(EmployeeBase):
    pass

class EmployeeUpdate(BaseModel):
    name: Optional[str]
    email: Optional[EmailStr]
    position: Optional[str]
    department: Optional[str]
    salary: Optional[int] = Field(None, ge=0)
    hire_date: Optional[date]
    status: Optional[str]

    @validator("status")
    def status_must_be_valid(cls, v):
        if v is None:
            return v
        if v not in ("active", "inactive"):
            raise ValueError("status must be 'active' or 'inactive'")
        return v

class EmployeeOut(EmployeeBase):
    id: int

    class Config:
        orm_mode = True
