from sqlalchemy.orm import Session
from sqlalchemy import func
from . import models, schemas
from typing import Optional

def get_employee(db: Session, employee_id: int):
    return db.query(models.Employee).filter(models.Employee.id == employee_id).first()

def get_employees(db: Session, skip: int = 0, limit: int = 100, department: Optional[str]=None, status: Optional[str]=None, search: Optional[str]=None):
    q = db.query(models.Employee)
    if department:
        q = q.filter(models.Employee.department == department)
    if status:
        q = q.filter(models.Employee.status == status)
    if search:
        like = f"%{search}%"
        q = q.filter(
            (models.Employee.name.ilike(like)) |
            (models.Employee.position.ilike(like)) |
            (models.Employee.department.ilike(like))
        )
    total = q.count()
    items = q.offset(skip).limit(limit).all()
    return total, items

def create_employee(db: Session, employee: schemas.EmployeeCreate):
    db_employee = models.Employee(**employee.dict())
    db.add(db_employee)
    db.commit()
    db.refresh(db_employee)
    return db_employee

def update_employee(db: Session, db_obj: models.Employee, updates: schemas.EmployeeUpdate):
    for field, value in updates.dict(exclude_unset=True).items():
        setattr(db_obj, field, value)
    db.add(db_obj)
    db.commit()
    db.refresh(db_obj)
    return db_obj

def delete_employee(db: Session, db_obj: models.Employee, soft: bool = True):
    if soft:
        db_obj.status = 'inactive'
        db.add(db_obj)
    else:
        db.delete(db_obj)
    db.commit()

def get_stats(db: Session):
    total = db.query(func.count(models.Employee.id)).scalar()
    by_dept = db.query(models.Employee.department, func.count(models.Employee.id)).group_by(models.Employee.department).all()
    avg_salary = db.query(models.Employee.department, func.avg(models.Employee.salary)).group_by(models.Employee.department).all()
    return {
        "total": total,
        "by_department": [{"department": d, "count": c} for d,c in by_dept],
        "average_salary_by_department": [{"department": d, "average_salary": float(a)} for d,a in avg_salary]
    }
